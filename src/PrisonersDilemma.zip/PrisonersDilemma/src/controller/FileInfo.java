package controller;


public class FileInfo {
	public static String lookupPath = "./lookups";
	public static String bestHillClimbFileName = "BestHillClimb";
	public static String utilyLookup = "utilyLookup";
	public static String APavlov = "ApavlovLookup";
}
