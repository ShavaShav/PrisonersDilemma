package model.strategy;

import ipdlx.Strategy;
import model.tool.History;
import model.tool.LookupArray1D;

public class MyTFTT extends Strategy{
	LookupArray1D lookup;
	History opponentHistory;
	
	public MyTFTT() {
		super("TFTT", "Tit for Two Tat", "Only defects if opponent defected twice in a row");
		
		opponentHistory = new History(2);
		lookup = new LookupArray1D(2);
		
		// set lookups
		lookup.setAction(new History("CC"), Strategy.COOPERATE);
		lookup.setAction(new History("CD"), Strategy.COOPERATE);
		lookup.setAction(new History("DC"), Strategy.COOPERATE);
		lookup.setAction(new History("DD"), Strategy.DEFECT);
	}

	@Override
	public double getMove() {
		// store opponents last move
		opponentHistory.add(opponentMove);
		// lookup appropriate action according to history
		return lookup.getAction(opponentHistory);
	}
	
	@Override
	public void reset(){
		opponentMove = (int) (Math.random() + 0.5); // reset to random
	}
}
